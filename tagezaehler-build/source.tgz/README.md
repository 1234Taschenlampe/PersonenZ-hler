# Tagezähler – Android-Homescreen-Widget

Native Android-App (Java) für Countdowns bis zum Geburtstag und zu beliebigen Terminen.
Entwickelt für den Pixel Launcher; funktioniert auch mit anderen Android-Launchern,
sofern diese App-Widgets unterstützen.

## Funktionen

- Beliebig viele Termine: Name, Datum, einmalig oder jedes Jahr wiederkehrend
- Geburtstage wiederholen sich jährlich; Sonderfall 29. Februar: in Nicht-Schaltjahren am 28. Februar
- Mehrere Widgets, jedes einzeln konfigurierbar: automatischer nächster Termin oder festes Ereignis
- Drei Farbverläufe: Türkis, Blau, Violett; abgerundete Ecken im Stil des gezeigten Duolingo-Widgets
- 1x1-Quadratwidget und größere Widget-Darstellung (vom Launcher und der Größe abhängig)
- Countdown in ganzen Kalendertagen, inklusive „HEUTE“ und verstrichenen Terminen
- Automatisches Aktualisieren über AppWidgetProvider und bei jeder Änderung; regelmäßiger Android-Widget-Refresh
- Keine Anmeldung, kein Internet, keine Werbung; optional Benachrichtigungsberechtigung für Sperrbildschirm-Countdown
- Android 8.0 und neuer (API 26+)

## APK mit Android Studio erstellen

1. ZIP entpacken.
2. Aktuelles **Android Studio** installieren und das Verzeichnis `CountdownWidget` öffnen.
3. Java 17 als Gradle-JDK einstellen, falls nicht automatisch erkannt.
4. Gradle synchronisieren lassen; Android SDK 36 und Build Tools gegebenenfalls installieren.
5. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Die installierbare Debug-APK liegt unter `app/build/outputs/apk/debug/app-debug.apk`.

Alternativ auf Windows mit JDK 17 und Android SDK 36:

```bat
gradlew.bat assembleDebug
```

Alternativ Linux/macOS:

```bash
./gradlew assembleDebug
```

Diese beiden Skripte laden Gradle bei Bedarf einmalig herunter.

## APK ohne lokalen Android-SDK-Build über GitHub Actions

1. Eigenes GitHub-Repository erstellen, die **Dateien aus dem entpackten Projektordner** (inklusive `.github/workflows/android.yml`) hochladen.
2. Repository → **Actions** → **Android APK erstellen** → **Run workflow**.
3. Nach erfolgreichem Durchlauf **Tagezaehler-Android-APK** unter Artifacts herunterladen.
4. ZIP entpacken und `app-debug.apk` auf das Android-Gerät übertragen und installieren.

Achtung: Die GitHub-Actions-Nutzung richtet sich nach den Kontolimits des GitHub-Kontos.

## Widget zum Startbildschirm hinzufügen

1. App installieren und starten.
2. „Meinen Geburtstag eintragen“ auswählen, Datum und jährliche Wiederholung festlegen.
3. Weitere Termine mit „Anderen Termin hinzufügen“ anlegen.
4. „Widget hinzufügen“ in der App drücken oder auf dem Homescreen lange drücken → **Widgets** → **Tagezähler**.
5. Termin und Farbe auswählen; mit „Widget hinzufügen“ bestätigen.
6. Für jeden weiteren Termin ein weiteres Widget anlegen. Über die Widget-Einstellungen kann die Auswahl geändert werden (Launcher-Unterstützung vorausgesetzt).

## Datenhaltung

Ereignisse liegen lokal in `SharedPreferences` und sind ohne App-Export nicht zwischen Geräten synchronisiert.
Ein Widget, das auf einen gelöschten Termin zeigt, zeigt einen Hinweis statt willkürlich einen anderen Termin anzuzeigen.

## Technische Hinweise

Die Zählung basiert auf `LocalDate` und unterscheidet sich daher nicht wegen Sommer-/Winterzeitwechseln.
Android legt den Zeitpunkt regelmäßiger Widget-Aktualisierungen selbst fest (mindestens 30 Minuten Intervall); eine Aktualisierung **exakt um Mitternacht** wird nicht garantiert. Bei Datums-/Zeitzonenänderungen und beim Bearbeiten von Terminen erfolgt ein zusätzlicher Aktualisierungsversuch.

Projektstatus: **Quellcode bereitgestellt, nicht gegen ein Android-Gerät kompiliert oder getestet.**
Das Build in Android Studio / GitHub Actions ist erforderlich, um eine echte APK zu erhalten.

## Version 1.1

- Widget belegt jetzt ab Werk 1x1 Startbildschirmfeld. Größere Darstellung per Vergrößern.
- Optionaler Countdown auf Sperrbildschirm als normale Android-Benachrichtigung; **kein** Zugriff auf native Pixel-Live-Anzeige.
- Ohne Shizuku, Smartspacer, Root oder Google-Verknüpfung.
- Update kann bei gleicher App-ID installiert werden; bei einer anderen APK-Signatur muss die vorherige APK deinstalliert werden (dabei gehen lokale Daten verloren).
