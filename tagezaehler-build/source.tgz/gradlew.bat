@echo off
setlocal
cd /d "%~dp0"
where gradle >nul 2>nul
if not errorlevel 1 (
  call gradle %*
  exit /b %ERRORLEVEL%
)
if not exist ".gradle-dist\gradle-8.13\bin\gradle.bat" (
  echo Lade Gradle 8.13 einmalig herunter...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; New-Item -ItemType Directory -Force .gradle-dist | Out-Null; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.13-bin.zip' -OutFile '.gradle-dist\gradle.zip'; Expand-Archive -Path '.gradle-dist\gradle.zip' -DestinationPath '.gradle-dist' -Force; Remove-Item '.gradle-dist\gradle.zip'"
  if errorlevel 1 exit /b 1
)
call ".gradle-dist\gradle-8.13\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
