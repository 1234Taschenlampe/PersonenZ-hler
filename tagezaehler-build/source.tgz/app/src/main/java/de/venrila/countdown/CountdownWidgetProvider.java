package de.venrila.countdown;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.RemoteViews;
import java.time.LocalDate;

public class CountdownWidgetProvider extends AppWidgetProvider {
    public static void refreshAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName component = new ComponentName(context, CountdownWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(component);
        for (int id : ids) render(context, manager, id);
    }

    public static void render(Context context, AppWidgetManager manager, int widgetId) {
        Bundle options = manager.getAppWidgetOptions(widgetId);
        int minWidth = options != null ? options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0) : 0;
        int minHeight = options != null ? options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0) : 0;
        boolean wide = minWidth >= 260 && minHeight >= 145;
        boolean square = minWidth < 105;
        RemoteViews views = new RemoteViews(context.getPackageName(),
                wide ? R.layout.widget_wide : square ? R.layout.widget_square : R.layout.widget_compact);

        int[] backgrounds = {R.drawable.widget_bg_teal, R.drawable.widget_bg_blue,
                R.drawable.widget_bg_violet};
        int theme = EventStore.widgetColor(context, widgetId);
        if (theme < 0 || theme >= backgrounds.length) theme = 0;
        views.setInt(R.id.widget_root, "setBackgroundResource", backgrounds[theme]);

        String selectedId = EventStore.widgetEvent(context, widgetId);
        CountdownEvent event = selectedId == null || selectedId.isEmpty()
                ? EventStore.next(context) : EventStore.find(context, selectedId);

        if (event == null) {
            views.setTextViewText(R.id.widget_title,
                    selectedId == null || selectedId.isEmpty() ? "Kein nächster Termin" : "Termin nicht gefunden");
            views.setTextViewText(R.id.widget_count, "–");
            views.setTextViewText(R.id.widget_status, "TAGE");
            views.setTextViewText(R.id.widget_date, "App öffnen");
        } else {
            LocalDate today = LocalDate.now();
            long remaining = event.remainingDays(today);
            views.setTextViewText(R.id.widget_title, event.name);
            String countText = Long.toString(Math.abs(remaining));
            views.setTextViewText(R.id.widget_count, countText);
            views.setTextViewTextSize(R.id.widget_count,
                    android.util.TypedValue.COMPLEX_UNIT_SP,
                    square ? (countText.length() >= 5 ? 13 : countText.length() >= 4 ? 17
                        : countText.length() >= 3 ? 22 : 27)
                    : countText.length() >= 5 ? (wide ? 33 : 22) :
                    countText.length() >= 4 ? (wide ? 41 : 27) : (wide ? 57 : 34));
            views.setTextViewText(R.id.widget_status,
                    remaining < 0 ? (remaining == -1 ? "TAG SEIT" : "TAGE SEIT")
                            : remaining == 0 ? "HEUTE" : remaining == 1 ? "TAG" : "TAGE");
            views.setTextViewText(R.id.widget_date, event.nextDateLabel(today));
        }
        Intent open = new Intent(context, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending = PendingIntent.getActivity(context, widgetId, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, pending);
        manager.updateAppWidget(widgetId, views);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) render(context, manager, id);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager,
                                         int widgetId, Bundle options) {
        render(context, manager, widgetId);
    }

    @Override
    public void onDeleted(Context context, int[] ids) {
        for (int id : ids) EventStore.removeWidget(context, id);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent.getAction();
        if (Intent.ACTION_DATE_CHANGED.equals(action)
                || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action)) {
            refreshAll(context);
        }
    }
}
