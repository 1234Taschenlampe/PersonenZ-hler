package de.venrila.countdown;

import org.json.JSONException;
import org.json.JSONObject;
import java.time.LocalDate;
import java.time.MonthDay;
import java.time.temporal.ChronoUnit;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.UUID;

public final class CountdownEvent {
    public final String id;
    public final String name;
    public final LocalDate date;
    public final boolean yearly;

    private static final DateTimeFormatter FORMAT =
            DateTimeFormatter.ofPattern("d. MMM yyyy", Locale.GERMANY);

    public CountdownEvent(String id, String name, LocalDate date, boolean yearly) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.yearly = yearly;
    }

    public static CountdownEvent create(String name, LocalDate date, boolean yearly) {
        return new CountdownEvent(UUID.randomUUID().toString(), name, date, yearly);
    }

    private LocalDate inYear(int year) {
        // Der 29. Februar wird in Nicht-Schaltjahren am 28. Februar angezeigt.
        MonthDay day = MonthDay.from(date);
        return day.isValidYear(year) ? day.atYear(year) : LocalDate.of(year, 2, 28);
    }

    public LocalDate targetDate(LocalDate today) {
        if (!yearly) return date;
        // Ein neu angelegter jährlicher Termin beginnt nicht schon vor dem
        // eingetragenen Ersttermin; historische Geburtstage funktionieren weiter.
        LocalDate reference = today.isBefore(date) ? date : today;
        LocalDate candidate = inYear(reference.getYear());
        return candidate.isBefore(reference) ? inYear(reference.getYear() + 1) : candidate;
    }

    public long remainingDays(LocalDate today) {
        return ChronoUnit.DAYS.between(today, targetDate(today));
    }

    public String nextDateLabel(LocalDate today) {
        return FORMAT.format(targetDate(today));
    }

    public String originalDateLabel() {
        return FORMAT.format(date);
    }

    public JSONObject toJson() throws JSONException {
        JSONObject object = new JSONObject();
        object.put("id", id);
        object.put("name", name);
        object.put("date", date.toString());
        object.put("yearly", yearly);
        return object;
    }

    public static CountdownEvent fromJson(JSONObject object) throws JSONException {
        return new CountdownEvent(
                object.getString("id"),
                object.getString("name"),
                LocalDate.parse(object.getString("date")),
                object.optBoolean("yearly", false));
    }
}
