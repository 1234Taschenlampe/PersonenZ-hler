package de.venrila.countdown;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class EventStore {
    private static final String PREFS = "countdown_data_v1";
    private static final String KEY_EVENTS = "events";
    private static final String KEY_EVENT_PREFIX = "widget_event_";
    private static final String KEY_COLOR_PREFIX = "widget_color_";

    private EventStore() { }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static List<CountdownEvent> all(Context context) {
        List<CountdownEvent> result = new ArrayList<>();
        String data = prefs(context).getString(KEY_EVENTS, "[]");
        try {
            JSONArray arr = new JSONArray(data);
            for (int i = 0; i < arr.length(); i++) {
                try {
                    result.add(CountdownEvent.fromJson(arr.getJSONObject(i)));
                } catch (RuntimeException | JSONException ignored) {
                    // Ein beschädigter Datensatz darf nicht sämtliche Termine verbergen.
                }
            }
        } catch (JSONException ignored) { }
        return result;
    }

    public static void upsert(Context context, CountdownEvent event) {
        List<CountdownEvent> list = all(context);
        boolean replaced = false;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(event.id)) {
                list.set(i, event);
                replaced = true;
                break;
            }
        }
        if (!replaced) list.add(event);
        save(context, list);
    }

    public static void delete(Context context, String id) {
        List<CountdownEvent> list = all(context);
        list.removeIf(event -> event.id.equals(id));
        save(context, list);
    }

    private static void save(Context context, List<CountdownEvent> list) {
        JSONArray arr = new JSONArray();
        for (CountdownEvent event : list) {
            try { arr.put(event.toJson()); } catch (JSONException ignored) { }
        }
        prefs(context).edit().putString(KEY_EVENTS, arr.toString()).apply();
        CountdownWidgetProvider.refreshAll(context);
    }

    public static List<CountdownEvent> sorted(Context context) {
        List<CountdownEvent> list = all(context);
        LocalDate today = LocalDate.now();
        list.sort(Comparator.comparingLong((CountdownEvent e) -> {
            long remaining = e.remainingDays(today);
            return remaining < 0 ? Long.MAX_VALUE + remaining : remaining;
        }).thenComparing(e -> e.name, String.CASE_INSENSITIVE_ORDER));
        return list;
    }

    public static CountdownEvent next(Context context) {
        LocalDate today = LocalDate.now();
        return sorted(context).stream()
                .filter(event -> event.remainingDays(today) >= 0)
                .findFirst().orElse(null);
    }

    public static CountdownEvent find(Context context, String id) {
        if (id == null) return null;
        for (CountdownEvent event : all(context)) {
            if (id.equals(event.id)) return event;
        }
        return null;
    }

    public static void setWidget(Context context, int widgetId, String eventId, int color) {
        prefs(context).edit()
                .putString(KEY_EVENT_PREFIX + widgetId, eventId)
                .putInt(KEY_COLOR_PREFIX + widgetId, color)
                .apply();
    }

    public static String widgetEvent(Context context, int widgetId) {
        return prefs(context).getString(KEY_EVENT_PREFIX + widgetId, "");
    }

    public static int widgetColor(Context context, int widgetId) {
        return prefs(context).getInt(KEY_COLOR_PREFIX + widgetId, 0);
    }

    public static void removeWidget(Context context, int widgetId) {
        prefs(context).edit()
                .remove(KEY_EVENT_PREFIX + widgetId)
                .remove(KEY_COLOR_PREFIX + widgetId)
                .apply();
    }
}
