package de.venrila.countdown;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class WidgetConfigActivity extends Activity {
    private int widgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private String chosenEventId = "";
    private int color = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(RESULT_CANCELED);
        Intent origin = getIntent();
        if (origin != null) {
            widgetId = origin.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
                    AppWidgetManager.INVALID_APPWIDGET_ID);
        }
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }
        chosenEventId = EventStore.widgetEvent(this, widgetId);
        color = EventStore.widgetColor(this, widgetId);
        draw();
    }

    private void draw() {
        LinearLayout root = Ui.vertical(this);
        root.setBackgroundColor(Ui.BG);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(0, bars.top, 0, bars.bottom);
            } else {
                view.setPadding(0, insets.getSystemWindowInsetTop(), 0,
                        insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        setContentView(root);

        ScrollView scroll = new ScrollView(this);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout content = Ui.vertical(this);
        content.setPadding(Ui.dp(this, 24), Ui.dp(this, 36),
                Ui.dp(this, 24), Ui.dp(this, 25));
        scroll.addView(content);

        content.addView(Ui.text(this, "Widget einrichten", 29, Ui.WHITE, true));
        content.addView(Ui.text(this, "Welcher Countdown soll auf deinem Startbildschirm erscheinen?",
                15, Ui.MUTED, false), Ui.lp(this, -1, -2, 8, 25));

        content.addView(Ui.text(this, "TERMIN", 12, Ui.ACCENT, true));
        RadioGroup eventGroup = new RadioGroup(this);
        eventGroup.setOrientation(RadioGroup.VERTICAL);
        RadioButton automatic = option("Immer den nächsten Termin anzeigen");
        eventGroup.addView(automatic);
        List<CountdownEvent> events = EventStore.sorted(this);
        List<RadioButton> eventButtons = new ArrayList<>();
        for (CountdownEvent event : events) {
            RadioButton button = option(event.name + "  ·  " + event.originalDateLabel());
            eventGroup.addView(button);
            eventButtons.add(button);
        }
        int selectedIndex = -1;
        for (int i = 0; i < events.size(); i++) {
            if (events.get(i).id.equals(chosenEventId)) selectedIndex = i;
        }
        if (selectedIndex == -1) automatic.setChecked(true);
        else eventButtons.get(selectedIndex).setChecked(true);
        eventGroup.setOnCheckedChangeListener((group, checkedId) -> {
            chosenEventId = "";
            for (int i = 0; i < eventButtons.size(); i++) {
                if (eventButtons.get(i).getId() == checkedId) {
                    chosenEventId = events.get(i).id;
                    break;
                }
            }
        });
        content.addView(eventGroup, Ui.lp(this, -1, -2, 8, 25));

        content.addView(Ui.text(this, "FARBE", 12, Ui.ACCENT, true));
        RadioGroup colors = new RadioGroup(this);
        colors.setOrientation(RadioGroup.VERTICAL);
        String[] options = {"Türkis", "Blau", "Violett"};
        RadioButton[] buttons = new RadioButton[3];
        for (int i = 0; i < options.length; i++) {
            buttons[i] = option(options[i]);
            colors.addView(buttons[i]);
        }
        if (color < 0 || color >= buttons.length) color = 0;
        buttons[color].setChecked(true);
        colors.setOnCheckedChangeListener((group, checkedId) -> {
            for (int i = 0; i < buttons.length; i++) {
                if (buttons[i].getId() == checkedId) color = i;
            }
        });
        content.addView(colors, Ui.lp(this, -1, -2, 8, 16));
        Button save = Ui.button(this, "Widget hinzufügen", true);
        save.setOnClickListener(v -> finishConfig());
        content.addView(save, Ui.lp(this, -1, Ui.dp(this, 56), 10, 0));
    }

    private RadioButton option(String label) {
        RadioButton button = new RadioButton(this);
        button.setId(android.view.View.generateViewId());
        button.setText(label);
        button.setTextColor(Ui.WHITE);
        button.setTextSize(15);
        button.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
        return button;
    }

    private void finishConfig() {
        EventStore.setWidget(this, widgetId, chosenEventId, color);
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        CountdownWidgetProvider.render(this, manager, widgetId);
        Intent result = new Intent();
        result.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        setResult(RESULT_OK, result);
        finish();
    }
}
