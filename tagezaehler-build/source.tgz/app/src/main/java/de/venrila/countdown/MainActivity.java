package de.venrila.countdown;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout listContainer;
    private TextView subtitle;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        showEvents();
    }

    private void buildUi() {
        LinearLayout root = Ui.vertical(this);
        root.setBackgroundColor(Ui.BG);
        // Android 15+ erzwingt Edge-to-Edge. Diese Insets halten Inhalte sichtbar.
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(0, bars.top, 0, bars.bottom);
            } else {
                view.setPadding(0, insets.getSystemWindowInsetTop(), 0,
                        insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        setContentView(root);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        LinearLayout content = Ui.vertical(this);
        int p = Ui.dp(this, 22);
        content.setPadding(p, Ui.dp(this, 27), p, Ui.dp(this, 36));
        scroll.addView(content);

        TextView overline = Ui.text(this, "DEINE VORFREUDE, AUF EINEN BLICK", 11,
                Ui.ACCENT, true);
        overline.setLetterSpacing(0.13f);
        content.addView(overline);

        TextView heading = Ui.text(this, "Tagezähler", 35, Ui.WHITE, true);
        content.addView(heading, Ui.lp(this, -1, -2, 10, 3));
        subtitle = Ui.text(this, "Die wichtigsten Tage im Blick.", 15, Ui.MUTED, false);
        content.addView(subtitle);

        Button birthday = Ui.button(this, "+  Meinen Geburtstag eintragen", true);
        birthday.setOnClickListener(v -> editEvent(null, true));
        content.addView(birthday, Ui.lp(this, -1, Ui.dp(this, 56), 26, 9));
        Button add = Ui.button(this, "+  Anderen Termin hinzufügen", false);
        add.setOnClickListener(v -> editEvent(null, false));
        content.addView(add, Ui.lp(this, -1, Ui.dp(this, 52), 0, 30));

        LinearLayout section = Ui.horizontal(this);
        TextView sectionName = Ui.text(this, "DEINE TERMINE", 12, Ui.MUTED, true);
        sectionName.setLetterSpacing(0.1f);
        section.addView(sectionName, new LinearLayout.LayoutParams(0, -2, 1));
        TextView hint = Ui.text(this, "Tippen zum Bearbeiten", 11, Ui.MUTED, false);
        section.addView(hint);
        content.addView(section);

        listContainer = Ui.vertical(this);
        content.addView(listContainer, Ui.lp(this, -1, -2, 12, 20));

        LinearLayout widgetCard = Ui.vertical(this);
        widgetCard.setPadding(Ui.dp(this, 19), Ui.dp(this, 19),
                Ui.dp(this, 19), Ui.dp(this, 19));
        widgetCard.setBackground(Ui.rounded(Ui.CARD, 22, this));
        TextView widgetTitle = Ui.text(this, "Auf deinen Startbildschirm", 19, Ui.WHITE, true);
        widgetCard.addView(widgetTitle);
        TextView desc = Ui.text(this,
                "Wie bei Duolingo: ein Countdown direkt auf dem Homescreen. " +
                        "Du kannst mehrere Widgets für unterschiedliche Termine anlegen.",
                14, Ui.MUTED, false);
        widgetCard.addView(desc, Ui.lp(this, -1, -2, 8, 14));
        Button pin = Ui.button(this, "Widget hinzufügen", true);
        pin.setOnClickListener(v -> pinWidget());
        widgetCard.addView(pin, Ui.lp(this, -1, Ui.dp(this, 50), 2, 0));
        content.addView(widgetCard);

        TextView fine = Ui.text(this,
                "Alle Termine bleiben auf deinem Gerät. Kein Konto, keine Werbung und keine Internetverbindung nötig.",
                12, Ui.MUTED, false);
        fine.setGravity(Gravity.CENTER);
        content.addView(fine, Ui.lp(this, -1, -2, 19, 0));
        showEvents();
    }

    private void showEvents() {
        if (listContainer == null) return;
        listContainer.removeAllViews();
        List<CountdownEvent> events = EventStore.sorted(this);
        subtitle.setText(events.isEmpty() ? "Lege deinen ersten Countdown an." :
                events.size() + (events.size() == 1 ? " Termin gespeichert" : " Termine gespeichert"));
        if (events.isEmpty()) {
            TextView empty = Ui.text(this, "Noch keine Termine. Trage deinen Geburtstag oder ein anderes Datum ein.",
                    15, Ui.MUTED, false);
            empty.setPadding(Ui.dp(this, 12), Ui.dp(this, 20),
                    Ui.dp(this, 12), Ui.dp(this, 22));
            listContainer.addView(empty);
            return;
        }
        LocalDate today = LocalDate.now();
        for (CountdownEvent event : events) {
            LinearLayout row = Ui.horizontal(this);
            row.setPadding(Ui.dp(this, 15), Ui.dp(this, 14),
                    Ui.dp(this, 13), Ui.dp(this, 14));
            row.setBackground(Ui.rounded(Ui.CARD, 18, this));
            row.setOnClickListener(v -> editEvent(event, false));

            LinearLayout info = Ui.vertical(this);
            TextView name = Ui.text(this, event.name, 16, Ui.WHITE, true);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            info.addView(name);
            String infoText = event.originalDateLabel() + (event.yearly ? " · jährlich" : " · einmalig");
            info.addView(Ui.text(this, infoText, 12, Ui.MUTED, false),
                    Ui.lp(this, -1, -2, 6, 0));
            row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));

            long days = event.remainingDays(today);
            LinearLayout count = Ui.vertical(this);
            count.setGravity(Gravity.CENTER);
            TextView number = Ui.text(this, String.valueOf(Math.abs(days)), 27, Ui.ACCENT, true);
            number.setGravity(Gravity.CENTER);
            number.setMaxWidth(Ui.dp(this, 95));
            count.addView(number);
            TextView unit = Ui.text(this, days == 0 ? "HEUTE" : days < 0 ? "VORBEI" :
                    Math.abs(days) == 1 ? "TAG" : "TAGE", 10, Ui.MUTED, true);
            unit.setGravity(Gravity.CENTER);
            count.addView(unit);
            row.addView(count, new LinearLayout.LayoutParams(Ui.dp(this, 74), -2));

            TextView delete = Ui.text(this, "×", 25, Ui.MUTED, false);
            delete.setGravity(Gravity.CENTER);
            delete.setContentDescription("Termin löschen: " + event.name);
            delete.setOnClickListener(v -> confirmDelete(event));
            row.addView(delete, new LinearLayout.LayoutParams(Ui.dp(this, 28), Ui.dp(this, 46)));
            listContainer.addView(row, Ui.lp(this, -1, -2, 0, 10));
        }
    }

    private void confirmDelete(CountdownEvent event) {
        new AlertDialog.Builder(this)
                .setTitle("Termin löschen?")
                .setMessage("\"" + event.name + "\" wird gelöscht. Widgets mit fest ausgewähltem Termin zeigen danach einen Hinweis an.")
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton("Löschen", (dialog, which) -> {
                    EventStore.delete(this, event.id);
                    showEvents();
                }).show();
    }

    private void editEvent(CountdownEvent current, boolean birthday) {
        LinearLayout editor = Ui.vertical(this);
        editor.setPadding(Ui.dp(this, 22), Ui.dp(this, 8),
                Ui.dp(this, 22), Ui.dp(this, 8));
        EditText nameInput = new EditText(this);
        nameInput.setSingleLine(true);
        nameInput.setText(current != null ? current.name : birthday ? "Mein Geburtstag" : "");
        nameInput.setHint("Name des Termins");
        nameInput.setSelectAllOnFocus(current == null && birthday);
        editor.addView(nameInput);

        LocalDate defaultDate = current != null ? current.date : LocalDate.now().plusDays(30);
        final LocalDate[] chosen = {defaultDate};
        Button dateButton = Ui.button(this, "Datum: " + chosen[0].format(
                java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy")), false);
        dateButton.setOnClickListener(v -> {
            DatePickerDialog picker = new DatePickerDialog(this, (view, year, month, day) -> {
                chosen[0] = LocalDate.of(year, month + 1, day);
                dateButton.setText("Datum: " + chosen[0].format(
                        java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy")));
            }, chosen[0].getYear(), chosen[0].getMonthValue() - 1, chosen[0].getDayOfMonth());
            picker.show();
        });
        editor.addView(dateButton, Ui.lp(this, -1, Ui.dp(this, 51), 14, 8));

        CheckBox yearly = new CheckBox(this);
        yearly.setText("Jedes Jahr wiederholen (z. B. Geburtstag)");
        yearly.setTextColor(Ui.WHITE);
        yearly.setChecked(current != null ? current.yearly : birthday);
        editor.addView(yearly);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(current != null ? "Termin bearbeiten" : birthday ? "Geburtstag eintragen" : "Neuer Termin")
                .setView(editor)
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton("Speichern", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(v -> {
                    String name = nameInput.getText().toString().trim();
                    if (name.isEmpty()) {
                        nameInput.setError("Bitte einen Namen eingeben");
                        return;
                    }
                    CountdownEvent saved = current == null
                            ? CountdownEvent.create(name, chosen[0], yearly.isChecked())
                            : new CountdownEvent(current.id, name, chosen[0], yearly.isChecked());
                    EventStore.upsert(this, saved);
                    showEvents();
                    dialog.dismiss();
                }));
        dialog.show();
    }

    private void pinWidget() {
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        ComponentName provider = new ComponentName(this, CountdownWidgetProvider.class);
        if (manager.isRequestPinAppWidgetSupported()) {
            boolean started = manager.requestPinAppWidget(provider, null, null);
            if (started) return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Widget hinzufügen")
                .setMessage("Auf dem Startbildschirm lange auf eine freie Stelle drücken, " +
                        "\"Widgets\" wählen und unter \"Tagezähler\" das Countdown-Widget hinzufügen.")
                .setPositiveButton("Verstanden", null)
                .show();
    }
}
