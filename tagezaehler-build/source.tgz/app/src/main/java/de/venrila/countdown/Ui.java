package de.venrila.countdown;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.util.TypedValue;

public final class Ui {
    public static final int BG = Color.rgb(13, 20, 36);
    public static final int CARD = Color.rgb(25, 37, 59);
    public static final int WHITE = Color.rgb(244, 250, 255);
    public static final int MUTED = Color.rgb(158, 177, 197);
    public static final int ACCENT = Color.rgb(65, 225, 191);
    public static final int DANGER = Color.rgb(245, 130, 137);

    private Ui() { }

    public static int dp(Context context, int units) {
        return (int) (units * context.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static GradientDrawable rounded(int color, int radius, Context context) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(context, radius));
        return drawable;
    }

    public static TextView text(Context context, String value, int sp, int color, boolean bold) {
        TextView view = new TextView(context);
        view.setText(value);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        return view;
    }

    public static Button button(Context context, String value, boolean primary) {
        Button button = new Button(context);
        button.setText(value);
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setTextColor(primary ? BG : WHITE);
        button.setBackgroundTintList(null);
        button.setBackground(rounded(primary ? ACCENT : CARD, 15, context));
        button.setPadding(dp(context, 16), dp(context, 9), dp(context, 16), dp(context, 9));
        return button;
    }

    public static LinearLayout vertical(Context context) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    public static LinearLayout horizontal(Context context) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(android.view.Gravity.CENTER_VERTICAL);
        return layout;
    }

    public static LinearLayout.LayoutParams lp(Context context, int width, int height,
                                                 int top, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(width, height);
        lp.setMargins(0, dp(context, top), 0, dp(context, bottom));
        return lp;
    }
}
