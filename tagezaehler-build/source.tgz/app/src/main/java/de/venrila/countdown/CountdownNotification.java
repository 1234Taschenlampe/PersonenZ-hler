package de.venrila.countdown;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import java.time.LocalDate;
import java.time.ZoneId;

public class CountdownNotification extends BroadcastReceiver {
    private static final String PREF = "countdown_notification";
    private static final String KEY_ENABLED = "enabled";
    private static final String CHANNEL = "countdown_days";
    private static final int NOTIFICATION_ID = 501;
    private static final String ACTION_REFRESH = "de.venrila.countdown.REFRESH";

    public static boolean enabled(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ENABLED, enabled).apply();
        refresh(context);
    }

    private static PendingIntent pending(Context context) {
        Intent intent = new Intent(context, CountdownNotification.class).setAction(ACTION_REFRESH);
        return PendingIntent.getBroadcast(context, 183, intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    public static boolean hasPermission(Context context) {
        return Build.VERSION.SDK_INT < 33 ||
                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        == PackageManager.PERMISSION_GRANTED;
    }

    public static void refresh(Context context) {
        NotificationManager nm = (NotificationManager)
                context.getSystemService(Context.NOTIFICATION_SERVICE);
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent trigger = pending(context);
        if (!enabled(context)) {
            nm.cancel(NOTIFICATION_ID);
            if (alarms != null) alarms.cancel(trigger);
            return;
        }
        if (hasPermission(context)) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL,
                    "Countdown auf Sperrbildschirm", NotificationManager.IMPORTANCE_LOW));
            CountdownEvent next = EventStore.next(context);
            if (next != null) {
                long days = next.remainingDays(LocalDate.now());
                String label = days == 0 ? "Heute" :
                        days == 1 ? "Noch 1 Tag" : "Noch " + days + " Tage";
                Intent open = new Intent(context, MainActivity.class);
                PendingIntent tap = PendingIntent.getActivity(context, 812, open,
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                Notification notice = new Notification.Builder(context, CHANNEL)
                        .setSmallIcon(R.drawable.ic_notification)
                        .setContentTitle(next.name + " · " + label)
                        .setContentText(next.nextDateLabel(LocalDate.now()))
                        .setContentIntent(tap)
                        .setAutoCancel(false)
                        .setOnlyAlertOnce(true)
                        .setVisibility(Notification.VISIBILITY_PUBLIC)
                        .setShowWhen(false)
                        .setCategory(Notification.CATEGORY_REMINDER)
                        .build();
                nm.notify(NOTIFICATION_ID, notice);
            } else {
                nm.cancel(NOTIFICATION_ID);
            }
        }
        if (alarms != null) {
            long tomorrow = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault())
                    .plusMinutes(2).toInstant().toEpochMilli();
            alarms.setWindow(AlarmManager.RTC, tomorrow, 30 * 60 * 1000L, trigger);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        refresh(context);
        CountdownWidgetProvider.refreshAll(context);
    }
}
